# Rubric for Pick a future by its Tuesday

**Problem:** `tuesday_task.md`.
**Threshold:** 1.0

The checks are the three checks at the end of `tuesday_task.md`, each mandatory:

### C1: No job name before the pick [mandatory]
- **Pass when:** no job name reaches the user or the moment scorers before the user picks.

### C2: Scores come with exact lines [mandatory]
- **Pass when:** every scored moment comes with a line copied word for word from its diary.

### C3: Moments are in the diaries [mandatory]
- **Pass when:** most moments show up in the diaries.
