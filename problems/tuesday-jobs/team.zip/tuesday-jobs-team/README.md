# Starter team

The team to copy for your own project. You talk to the orchestrator; it gives each agent its task, one job each, and reports back to you.

```
planner → you → implementer → reviewer → verifier → report-writer
                    ↑              │ NEEDS FIX  │ FAIL
                    └──────────────┴────────────┘
```

The planner plans the work and the checks the result must pass, and you approve both. The implementer makes the result, the reviewer lists fixes, the verifier checks the result against the approved checks, and the report writer writes your report. A NEEDS FIX or a FAIL sends the work back for a fix.

## Make it yours

1. Copy this folder and give the copy your project's name.
2. Keep the agents that fit your project and delete the rest. Add an agent from `.opencode/agent_template.md` only when a job needs a different one, and add its step to `.opencode/commands/do.md`.
3. Write your project's details (what to make, how many, what you decide) in a task file in the folder, such as `my_task.md`.

## Run it

1. In OpenCode, open your team folder, not AgentTeams.
2. Start a new chat for each run. Type `/do Read my_task.md.` (or the full task after `/do`).
3. Read the plan and its checks, and approve them or ask for changes.
4. Each run gets its own folder, `runs/run_1/`, `runs/run_2/` and so on: the result in `deliverable/`, each agent's notes in `logs/`, and your report as `report.docx`. Open the report in Word, fill in your judgment and notes, and hand it in.

## What is in the folder

The files that start with a dot are hidden: show them with Command + Shift + period on Mac, View › Show › Hidden items on Windows, or Ctrl + H on Linux.

- `opencode.json`: the model and what the agents may do. Agents may read and write anything in this folder; anything outside it asks first.
- `.opencode/agents/`: one short file per agent: what it does, and its job in one line. `orchestrator.md` is empty on purpose: its instructions live in `/do`.
- `.opencode/commands/do.md`: the saved prompt behind `/do`, the run order and the plan pause.
- `.opencode/agent_template.md`: copy it into `.opencode/agents/` to add an agent.
- `AGENTS.md`: rules every agent reads (plain sentences, work only inside this folder, how to delete).
- `.opencode/plugins/run-cost-limit.js`: limits each chat and its agents to about $2. Calls already running can go over. Type `/add-dollar` in that chat to add $1 and continue. Helper agents start in the foreground, so Stop stops them too (unless you press Ctrl+B).
- `.opencode/plugins/delete-guard.js`: refuses deletes and moves outside this folder until you type `yes, delete <full path>`.
- `.opencode/plugins/report-docx.js` and `.opencode/vendor/`: turn `report.md` into `report.docx` inside OpenCode, so you install nothing.
- `tools/render_page.py`: lets the team look at a web page it made, the way a reader would. It needs Python and Playwright, so it matters only when your result is a web page.

These rules prevent accidents; they do not lock the agents in. Keep files you care about out of AgentTeams.
