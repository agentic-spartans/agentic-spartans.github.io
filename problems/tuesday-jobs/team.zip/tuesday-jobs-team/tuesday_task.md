Pick a future by what an ordinary Tuesday in it is like.
- The planner writes 10 workday moments in a file. I rate each 1 to 5 there; wait for me.
- Diary writers write an ordinary Tuesday for each of 50 jobs, about 150 words, without naming the job.
- Moment scorers score each diary for the moments, without seeing job names.
- When the checks pass, show me the best diaries by code. I pick one; then tell me its job.

Checks:
1. No job name reaches me or the moment scorers before I pick.
2. Every scored moment comes with a line copied word for word from its diary.
3. Most moments show up in the diaries.
