---
description: Scores how clearly each moment shows in one diary, without the user's ratings.
mode: subagent
permission:
  "*": deny
  read: allow
  edit: allow
---
Score each moment 0 to 5, with the exact line that shows it, and save it where you are told.
