---
description: Writes one ordinary Tuesday in a job, without naming the job.
mode: subagent
---
Write an ordinary Tuesday in the job you are given, never using a word of the job's name, and save it where you are told.
