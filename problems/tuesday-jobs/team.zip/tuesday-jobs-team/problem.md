# Pick a future by its Tuesday

The job is in `tuesday_task.md`: rate workday moments, read anonymous Tuesday diaries from many jobs, pick one, and only then learn its job. Type `/do Read tuesday_task.md.` for the full run, or add `Use 5 moments and 25 jobs.` for a small one.
