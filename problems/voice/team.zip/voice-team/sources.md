# Evidence packet: candidate reference sources

Studio-authored paraphrase of the cited public sources, with their numbers; no text quoted. Check the cited source for the original wording.

This packet is the numerical authority for the run. Each source below is summarized in the studio's own words, with every number, group, task, software package and statistic type (SD, SE or range) kept as in the source. A `judgments.csv` row cites a source by its id and table. The verifier opens the URL where its tool can; otherwise it checks against this packet and says so. The sources keep their own rights.

## S1. Goy, H. (2016). Speech communication by younger and older adults: the effects of age-related vocal changes, environmental noise and simulated listener demands. PhD thesis, University of Toronto.
URL: https://utoronto.scholaris.ca/bitstream/1807/76499/1/Goy_Huiwen_201611_PhD_thesis.pdf (item page https://utoronto.scholaris.ca/handle/1807/76499; free download; repository notice: all rights reserved). Chapter 2 is the dataset published as Goy, Fernandes, Pichora-Fuller and van Lieshout (2013), Journal of Voice 27(5), 545-555, which is not free to read. Page numbers below are the thesis's printed numbers, with the PDF page in parentheses.

Participants, printed page 24 (PDF 41):
- Younger group: 159 adults, mean age 19.1 years (range 18-28, SD 1.4), recruited from the undergraduate population at the University of Toronto. 104 females and 55 males.
- Older group: 133 community-dwelling adults, mean age 72.0 years (range 63-86, SD 4.8), recruited in the Greater Toronto Area. 82 females and 51 males.
- Every participant had acquired English before age 5 in an English-speaking country, and reported no diagnosed speech, voice or neurological disorder. Current smokers were excluded.

Table 2.1, printed page 27 (PDF 44), demographic and lifestyle characteristics, with ranges in parentheses. Mean age in years:
- Males, younger (N=55): 19.4 (range 18-28)
- Males, older (N=51): 73.3 (range 65-86)
- Females, younger (N=104): 18.9 (range 18-27)
- Females, older (N=82): 71.1 (range 63-82)

Tasks, printed pages 29 to 31 (PDF 46 to 48):
- Habitual Pitch task: sustain [a] for eight seconds at the participant's usual comfortable pitch, with loudness near 75 dB C.
- Maximum Pitch task: sustain [a] for eight seconds at the highest pitch the participant could hold without a voice break or excessive strain.
- Reading task: the first paragraph of the Rainbow Passage (Fairbanks, 1960), used in place of the whole passage.
- The program derived three speech measures over the entire reading: mean speaking fundamental frequency (SF0), its standard deviation (SF0SD), and mean intensity. Each participant's value averages three readings.
- Voice measures came from a 4-second segment of each 8-second Habitual Pitch recording, chosen by the Sonneta software; the best three trials were averaged.
- The study has no lowest-pitch task and reports no within-recording F0 variation for the sustained vowel.

Table 2.2, printed page 33 (PDF 50), normative values for younger and older males, at the 10th, 25th, 50th, 75th and 90th percentiles. Younger males n=55; older males n=51.

| Measure | Younger males (10th, 25th, 50th, 75th, 90th) | Older males (10th, 25th, 50th, 75th, 90th) |
|---|---|---|
| F0 (Hz) | 104, 114, 123, 145, 158 | 97, 109, 121, 138, 179 |
| MaxF0 (Hz) | 203, 344, 433, 514, 600 | 231, 278, 357, 438, 502 |
| SF0 (Hz) | 98, 107, 115, 127, 140 | 98, 105, 110, 126, 141 |
| SF0SD (Hz) | 17, 19, 26, 31, 36 | 16, 19, 25, 30, 37 |
| Jitter (%) | 0.23, 0.28, 0.35, 0.49, 0.59 | 0.25, 0.33, 0.42, 0.59, 0.74 |
| Shimmer (%) | 1.38, 1.90, 2.71, 3.22, 4.02 | 1.79, 2.25, 3.91, 5.59, 7.32 |
| HNR (dB) | 19.6, 20.9, 22.5, 25.3, 26.3 | 17.3, 19.9, 21.8, 24.2, 27.5 |

Table 2.3, printed page 34 (PDF 51), normative values for younger and older females, same percentiles. Younger females n=104; older females n=82.

| Measure | Younger females (10th, 25th, 50th, 75th, 90th) | Older females (10th, 25th, 50th, 75th, 90th) |
|---|---|---|
| F0 (Hz) | 213, 230, 249, 273, 293 | 169, 182, 203, 236, 262 |
| MaxF0 (Hz) | 363, 426, 519, 586, 683 | 363, 439, 509, 592, 692 |
| SF0 (Hz) | 183, 195, 207, 219, 234 | 150, 157, 170, 191, 203 |
| SF0SD (Hz) | 34, 39, 45, 51, 57 | 27, 31, 38, 45, 52 |
| Jitter (%) | 0.21, 0.24, 0.30, 0.43, 0.55 | 0.19, 0.25, 0.35, 0.58, 1.01 |
| Shimmer (%) | 1.44, 1.73, 2.16, 2.88, 3.44 | 1.30, 1.75, 2.24, 3.37, 5.03 |
| HNR (dB) | 21.4, 23.3, 25.0, 27.5, 29.0 | 20.8, 22.8, 25.2, 28.4, 30.3 |

Table 2.4, printed page 36 (PDF 53), descriptive statistics for males, mean with SD in parentheses. Younger males n=55; older males n=51.

| Measure | Younger males | Older males |
|---|---|---|
| F0 (Hz) | 128 (21) | 127 (27) |
| MaxF0 (Hz) | 425 (141) | 363 (103) |
| SF0 (Hz) | 118 (17) | 116 (16) |
| SF0sd (Hz) | 26 (8) | 25 (8) |
| Jitter (%) | 0.38 (0.13) | 0.48 (0.20) |
| Shimmer (%) | 2.71 (0.99) | 4.17 (2.13) |
| HNR (dB) | 22.9 (2.7) | 21.9 (3.8) |

Table 2.5, printed page 38 (PDF 55), descriptive statistics for females, mean with SD in parentheses. Younger females n=104; older females n=82.

| Measure | Younger females | Older females |
|---|---|---|
| F0 (Hz) | 251 (28) | 211 (42) |
| MaxF0 (Hz) | 517 (124) | 520 (120) |
| SF0 (Hz) | 208 (19) | 174 (22) |
| SF0SD (Hz) | 45 (9) | 38 (10) |
| Jitter (%) | 0.37 (0.25) | 0.47 (0.34) |
| Shimmer (%) | 2.36 (0.91) | 2.78 (1.79) |
| HNR (dB) | 25.3 (3.1) | 25.3 (3.8) |

Jitter (%), shimmer (%) and HNR (dB) were obtained from the Habitual Pitch recordings by the Sonneta waveform-matching software (printed page 31), not by Praat. Tables 2.2 to 2.5 also contain a maximum phonation time row, which this problem does not need.

Measures the source does not report: lowest F0 or phonational range, CPPS or any other cepstral measure, and within-recording F0 SD of the sustained vowel.

## S2. Murton, O., Hillman, R., Mehta, D. (2020). Cepstral peak prominence values for clinical voice evaluation. American Journal of Speech-Language Pathology 29(3), 1596-1607.
URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC7893528/ (open access under a Creative Commons Attribution 4.0 International License; full text also at https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7893528/fullTextXML).

Speakers (Experiment 1): 295 patients with a medical diagnosis of a voice disorder and 50 vocally healthy controls. Each speaker produced sustained /a/ vowels and read the English-language Rainbow Passage.

Table 3, sex and age distribution of speakers:
- Controls: 30 female, 20 male; median age 36.5; range 22-59.
- Patients: 183 female, 112 male; median age 45; range 13-93.

Language of the speakers: the paper says it differs from earlier work by running both ADSV and Praat on two English-language data sets to derive CPP cut-offs for flagging likely voice disorders. The discussion presents it as the first to supply CPP values from both methods on shared, carefully controlled databases of English speakers.

Praat settings: every recording additionally went through Praat (version 6.0.40) with a PowerCepstrogram with pitch floor 60 Hz, time step 2 ms, maximum frequency 5 kHz and pre-emphasis from 50 Hz. CPPS was computed from each PowerCepstrogram with: subtract tilt before smoothing off ("no"); time averaging window 0.01 s; quefrency averaging window 0.001 s; peak search pitch range 60-330 Hz; tolerance 0.05; parabolic interpolation; tilt line quefrency range from 0.001 s with no upper bound; straight line type; robust fit method. The same settings applied to the sustained vowels and to the Rainbow Passage.

Table 4, threshold values and performance of the classifiers based on Analysis of Dysphonia in Speech and Voice (ADSV) cepstral peak prominence (CPP) and Praat smoothed CPP (CPPS):

| | ADSV CPP, sustained vowels | ADSV CPP, Rainbow Passage | Praat CPPS, sustained vowels | Praat CPPS, Rainbow Passage |
|---|---|---|---|---|
| Threshold | 11.46 dB | 6.11 dB | 14.45 dB | 9.33 dB |
| Accuracy | 79.4% | 87.7% | 77.4% | 94.5% |

Per the text, CPP values under these thresholds point to a voice disorder. The discussion says men tended to have higher CPP than women, and that CPP can be influenced by vowel quality, loudness, and the speaker's sex and age. The paper tabulates no group mean or SD of CPPS for a healthy group.

## S3. Eichhorn, J. T., Kent, R. D., Austin, D., Vorperian, H. K. (2018). Effects of aging on vocal fundamental frequency and vowel formants in men and women. Journal of Voice 32(5).
URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC5832520/ (NIH author manuscript, free to read).

Participants: 96 healthy adults (43 male, 53 female), aged 20 to 92 years, all native English speakers.
- Cohort I, young adults aged 20 to 30: 19 males, 21 females.
- Cohort II, middle-aged adults aged 40 to 60: 12 males, 20 females.
- Cohort III, older adults aged 70 to 92: 12 males, 12 females.

Task: 20 distinct monosyllabic American English words, each repeated at a normal loudness. The vowel part of each word was analyzed for fo and the first four formants with the TF32 acoustic analysis software. The analysis used mixed effects models; Table 2 gives the model means (least squares means).

Table 2, least squares means from mixed models, mean with SE in parentheses:

| Measure | Female 20-30 | Female 40-60 | Female 70+ | Male 20-30 | Male 40-60 | Male 70+ |
|---|---|---|---|---|---|---|
| fo /ɑ/ | 200 (4.31) | 165 (4.42) | 170 (5.71) | 102 (4.55) | 108 (5.70) | 119 (5.71) |
| fo /i/ | 212 (4.65) | 177 (4.78) | 188 (6.16) | 108 (4.90) | 115 (6.15) | 125 (6.16) |

The parenthesized values are standard errors of least-squares means from a mixed model with repeated words per speaker. They are not standard deviations.

## S4. Sydney Voice Lab, University of Sydney. Acoustic analysis normative data reference sheet, last updated April 2025.
URL: https://www.sydney.edu.au/content/dam/corporate/documents/faculty-of-medicine-and-health/research/research-centres/sydney-voice-lab/acoustic-analysis-normative-data-reference-sheet-20250416_v4.0-sydney-voice-lab.pdf.coredownload.pdf (public PDF, 4 pages). A secondary compilation; each row names a primary source.

- PDF page 1, row "Average Fundamental Frequency (F0)", described as the natural mean pitch of the voice in conversation: males 115 Hz (SD 21); females 199 Hz (SD 28). Primary source named: Leung, Y., Oates, J., Papp, V., & Chan, S.P. (2022). Speaking fundamental frequencies of adult speakers of Australian English and effects of sex, age, and geographical location. Journal of Voice, 36(3), 434-e1. The primary is not free to read; the sheet gives no age band.
- PDF page 1, row "Pitch Range", described as the highest and lowest pitch of the voice: males 78-698 Hz; females 139-1108 Hz. The sheet adds a note that this paper involved participants with voice or singing training. Primary source named: Hollien, H., Dew, D., & Philips, P. (1971). Phonational frequency ranges of adults. Journal of Speech and Hearing Research, 14(4), 755-760. The primary is not free to read; the sheet gives a group range only, with no mean or SD and no age band.

## Not in the packet (paywalled, no public table)
Goy et al. 2013 (J Voice); Hollien, Dew and Philips 1971 (JSHR); Leung et al. 2022 (J Voice). A `judgments.csv` row may cite a public source outside this packet if the verifier can open it and confirm the table; the matching conditions still apply.
