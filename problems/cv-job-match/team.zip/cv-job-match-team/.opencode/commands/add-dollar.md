---
description: Add $1 to this run's cost limit and continue the same run
agent: orchestrator
---

[run-cost-limit:add-1]
The user added $1 to this run's cost limit. Continue the run from the checkpoint at the end of `logs/log.md` in the run folder named below.
