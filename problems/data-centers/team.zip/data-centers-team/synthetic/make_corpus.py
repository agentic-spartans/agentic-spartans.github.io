#!/usr/bin/env python3
"""Generate a synthetic news-like corpus with planted topics, trends and a correlated topic pair.

    python3 make_corpus.py --seed SEED --topics K --out DOCS_DIR --truth TRUTH_DIR
                           --start YYYY-MM --months N [--per-month D]

Documents are drawn from a latent Dirichlet allocation model whose parameters are known, so
a topic-modelling pipeline can be tested against the truth:

- K topics (4 to 10) over a fixed vocabulary of 800 pseudo-words (letters only, 5 to 8 letters,
  none in the stopword list), each topic a Dirichlet(0.02) draw over the vocabulary.
- A planted monthly mean share per topic, from normalized logits: topic 0 rises (logit from log 0.08
  to log 0.30, log-linear), topic 1 falls (log 0.25 to log 0.08), topics 2 and 3 move together with
  one sinusoidal factor of amplitude 1 in log space, and the K - 4 background topics have a constant
  logit (log 0.15). Because the shares are normalized each month, the background shares are not
  constant (about 10% to 21%): they move with the complement of the planted four.
- Each document: a topic mixture theta ~ Dirichlet(0.3 * K * monthly mean), a length of
  Poisson(120) + 20 tokens, tokens drawn from the mixture, written in random order; a date
  drawn uniformly inside its month.

Writes DOCS_DIR/docs.csv with the columns doc_id, date, outlet, title, url, query, retrieved, text
(url, query and retrieved empty), the layout of the task's corpus_text.csv, and
in TRUTH_DIR: params.json (K, seed, which topics carry the planted structure), topic_word.csv
(K rows, one column per word), doc_topic.csv (doc_id and the realized theta per topic),
period_share.csv (calendar quarter YYYYQn, n_docs, realized mean theta per topic). The
vocabulary is the same for every seed; the topics, the mixtures and the texts change with it.
"""

import argparse
import csv
import json
import os
import random

import numpy as np

VOCAB_SIZE = 800
ETA = 0.02
ALPHA0 = 0.3
MEAN_LENGTH = 120
MIN_LENGTH = 20


def pseudo_vocabulary(size, stopwords):
    rng = random.Random(20261008)
    consonants = "bdfgklmnprstvz"
    vowels = "aeiou"
    words = []
    seen = set(stopwords)
    while len(words) < size:
        n = rng.choice([3, 3, 4])
        w = "".join(rng.choice(consonants) + rng.choice(vowels) for _ in range(n))
        if rng.random() < 0.3:
            w += rng.choice(consonants)
        if 5 <= len(w) <= 8 and w not in seen:
            seen.add(w)
            words.append(w)
    return words


def planted_means(K, months):
    """Monthly mean shares from normalized logits: topic 0's logit runs log-linearly from log 0.08 to
    log 0.30, topic 1's from log 0.25 to log 0.08, topics 2 and 3 share log 0.15 plus one sinusoidal
    factor of amplitude 1 (1.5 cycles over the window), and every background topic has the constant
    logit log 0.15. After normalization every share also moves with the others' complement: the
    background shares vary between about 10% and 21% of the mass rather than staying constant, which
    is why the scorer judges only the four planted-structure topics and sums the background topics."""
    t = np.linspace(0.0, 1.0, months)
    factor = np.sin(2 * np.pi * 1.5 * t)
    logit = np.full((months, K), np.log(0.15))
    logit[:, 0] = np.log(0.08) + (np.log(0.30) - np.log(0.08)) * t
    logit[:, 1] = np.log(0.25) + (np.log(0.08) - np.log(0.25)) * t
    logit[:, 2] = np.log(0.15) + factor
    logit[:, 3] = np.log(0.15) + factor
    mean = np.exp(logit)
    return mean / mean.sum(axis=1, keepdims=True)


def month_sequence(start, months):
    year, month = int(start[:4]), int(start[5:7])
    out = []
    for _ in range(months):
        out.append((year, month))
        month += 1
        if month == 13:
            month, year = 1, year + 1
    return out


def days_in_month(year, month):
    if month == 12:
        return 31
    import datetime
    return (datetime.date(year, month + 1, 1) - datetime.date(year, month, 1)).days


def quarter_label(year, month):
    return f"{year}Q{(month - 1) // 3 + 1}"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--topics", type=int, required=True, help="planted number of topics, 4 to 10")
    ap.add_argument("--out", required=True, help="folder for docs.csv")
    ap.add_argument("--truth", required=True, help="folder for the truth files")
    ap.add_argument("--start", required=True, help="first month, YYYY-MM")
    ap.add_argument("--months", type=int, required=True)
    ap.add_argument("--per-month", type=int, default=40)
    ap.add_argument("--stopwords", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "stopwords.txt"))
    a = ap.parse_args()
    if not 4 <= a.topics <= 10:
        raise SystemExit("--topics must be between 4 and 10")
    stop = set()
    if os.path.exists(a.stopwords):
        stop = {w.strip() for w in open(a.stopwords, encoding="utf-8") if w.strip()}
    vocab = pseudo_vocabulary(VOCAB_SIZE, stop)
    K = a.topics
    rng = np.random.default_rng(a.seed)
    beta = rng.dirichlet(np.full(VOCAB_SIZE, ETA), size=K)
    months = month_sequence(a.start, a.months)
    mean = planted_means(K, a.months)

    os.makedirs(a.out, exist_ok=True)
    os.makedirs(a.truth, exist_ok=True)
    docs, thetas = [], []
    for mi, (year, month) in enumerate(months):
        for _ in range(a.per_month):
            theta = rng.dirichlet(ALPHA0 * K * mean[mi])
            n = rng.poisson(MEAN_LENGTH) + MIN_LENGTH
            counts = rng.multinomial(n, theta @ beta)
            tokens = np.repeat(np.arange(VOCAB_SIZE), counts)
            rng.shuffle(tokens)
            day = int(rng.integers(1, days_in_month(year, month) + 1))
            docs.append((f"{year:04d}-{month:02d}-{day:02d}", quarter_label(year, month), " ".join(vocab[i] for i in tokens)))
            thetas.append(theta)
    order = np.argsort([d[0] for d in docs], kind="stable")
    ids = {}
    with open(os.path.join(a.out, "docs.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["doc_id", "date", "outlet", "title", "url", "query", "retrieved", "text"])
        for rank, i in enumerate(order, 1):
            doc_id = f"S{rank:04d}"
            ids[i] = doc_id
            w.writerow([doc_id, docs[i][0], "synthetic", f"Synthetic document {doc_id}", "", "", "", docs[i][2]])

    with open(os.path.join(a.truth, "topic_word.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["topic"] + vocab)
        for k in range(K):
            w.writerow([f"topic_{k}"] + [f"{x:.8g}" for x in beta[k]])
    with open(os.path.join(a.truth, "doc_topic.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["doc_id", "date", "quarter"] + [f"topic_{k}" for k in range(K)])
        for i in order:
            w.writerow([ids[i], docs[i][0], docs[i][1]] + [f"{x:.8g}" for x in thetas[i]])
    quarters = sorted({d[1] for d in docs})
    th = np.array(thetas)
    qlab = np.array([d[1] for d in docs])
    with open(os.path.join(a.truth, "period_share.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["quarter", "n_docs"] + [f"topic_{k}" for k in range(K)])
        for q in quarters:
            sel = qlab == q
            w.writerow([q, int(sel.sum())] + [f"{x:.8g}" for x in th[sel].mean(axis=0)])
    json.dump({"topics": K, "seed": a.seed, "start": a.start, "months": a.months, "per_month": a.per_month,
               "rising": 0, "falling": 1, "comoving": [2, 3], "vocab_size": VOCAB_SIZE,
               "monthly_mean_share": mean.round(6).tolist()},
              open(os.path.join(a.truth, "params.json"), "w"), indent=1)
    print(f"wrote {len(docs)} documents to {a.out}/docs.csv and the truth to {a.truth}/ (K={K}, seed={a.seed})")


if __name__ == "__main__":
    main()
