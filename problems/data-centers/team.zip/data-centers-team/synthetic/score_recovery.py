#!/usr/bin/env python3
"""Score a topic-model pipeline's output on a synthetic corpus against the planted truth.

    python3 score_recovery.py --truth TRUTH_DIR --fit FIT_DIR [--json OUT.json]

TRUTH_DIR is what make_corpus.py wrote. FIT_DIR holds the pipeline's outputs in the task's
formats: k_choice.json (chosen_k), topic_word_full.csv (one row per fitted topic, one column per
term, probabilities), doc_topics.csv (doc_id, date, quarter, top_topic, topic_<k> columns) and
period_share.csv (quarter, n_docs, topic_<k> columns).

Fitted topics are matched one-to-one to the true topics by the Hungarian algorithm on the cosine
similarity of their word distributions (over the union of the two vocabularies; a term absent from
one side counts as probability 0); that matching gives the COSINE check. A true topic left without a
partner (fewer fitted than true topics) scores cosine 0. For the mixture and share checks (TV, TREND,
CORR) every fitted topic is assigned to the true topic it is most similar to, and the fitted shares
assigned to one true topic are summed, so a true topic that the model split in two (the chosen K one
above the planted K) is compared as a whole. Checks and tolerances:

  K        chosen_k within 1 of the planted K
  COSINE   each of the four planted-structure topics (rising, falling, the two co-moving) matched
           with cosine >= 0.90 (the background topics' cosines are reported, not judged: their shares
           are not planted constants, and with the chosen K one below the planted K two of them merge,
           which is the rule's tolerance)
  TV       mean over documents of the total-variation distance between the true and the fitted
           topic mixture, with the planted-structure topics kept apart and all background topics summed
           into one "other" share on both sides, <= 0.12
  TREND    for the rising, the falling and the two co-moving topics, Pearson r between the fitted
           and the realized quarterly share >= 0.95, and for the rising and the falling topic the
           ratio of the fitted to the realized linear slope over the quarters within 0.7 to 1.3
  CORR     for every pair among the four planted-structure topics (rising, falling, the two
           co-moving), the correlation across quarters of the fitted shares differs from that of
           the realized shares by at most 0.15 (the worst pair over all topics is reported too)

Prints one line per check and a final line RECOVERY: PASS or RECOVERY: FAIL.
"""

import argparse
import csv
import json
import os
import sys

import numpy as np
from scipy.optimize import linear_sum_assignment

TOL = {"k": 1, "cosine": 0.90, "tv": 0.12, "trend_r": 0.95, "slope_lo": 0.7, "slope_hi": 1.3, "corr": 0.15}


def read_matrix(path, key, only_topics=False):
    """Rows named by the key column; the other columns (or only the topic_<k> columns) as floats."""
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows or key not in rows[0]:
        print(f"FILE    FAIL  {os.path.basename(path)} is empty or lacks a {key!r} column")
        print("RECOVERY: FAIL")
        sys.exit(1)
    header = rows[0]
    ki = header.index(key)
    names = [r[ki] for r in rows[1:]]
    cols = [c for c in header if c != key and (not only_topics or (c.startswith("topic_") and c[6:].isdigit()))]
    idx = [header.index(c) for c in cols]
    M = np.array([[float(r[i]) if r[i] != "" else np.nan for i in idx] for r in rows[1:]], dtype=float).reshape(len(rows) - 1, len(cols))
    return names, cols, M


def topic_columns(cols):
    return [c for c in cols if c.startswith("topic_") and c[6:].isdigit()]


def pearson(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if x.std() == 0 or y.std() == 0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--truth", required=True)
    ap.add_argument("--fit", required=True)
    ap.add_argument("--json")
    a = ap.parse_args()

    params = json.load(open(os.path.join(a.truth, "params.json")))
    K = params["topics"]
    results = {}
    ok_all = True

    def report(name, ok, text):
        nonlocal ok_all
        ok_all = bool(ok_all and ok)
        results[name] = {"pass": bool(ok), "detail": text}
        print(f"{name:7s} {'PASS' if ok else 'FAIL'}  {text}")

    # K
    choice = json.load(open(os.path.join(a.fit, "k_choice.json")))
    k_fit = int(choice["chosen_k"])
    report("K", abs(k_fit - K) <= TOL["k"], f"chosen {k_fit}, planted {K}, tolerance +-{TOL['k']}")

    structured = [params["rising"], params["falling"]] + list(params["comoving"])
    other = [i for i in range(K) if i not in structured]

    # topic matching on word distributions
    tnames0, tcols, TW0 = read_matrix(os.path.join(a.truth, "topic_word.csv"), "topic")
    row_of = {n: i for i, n in enumerate(tnames0)}
    missing_rows = [f"topic_{i}" for i in range(K) if f"topic_{i}" not in row_of]
    if missing_rows:
        raise SystemExit(f"truth topic_word.csv lacks rows {missing_rows}")
    tnames = [f"topic_{i}" for i in range(K)]  # planted topic i is the row named topic_i, whatever the file order
    TW = TW0[[row_of[n] for n in tnames]]
    fnames, fcols, FW = read_matrix(os.path.join(a.fit, "topic_word_full.csv"), "topic")
    if FW.shape[0] != k_fit:
        print(f"note: topic_word_full.csv has {FW.shape[0]} rows, k_choice.json says {k_fit}")
    terms = sorted(set(tcols) | set(fcols))
    ti = {t: i for i, t in enumerate(terms)}
    T = np.zeros((TW.shape[0], len(terms)))
    T[:, [ti[c] for c in tcols]] = TW
    F = np.zeros((FW.shape[0], len(terms)))
    F[:, [ti[c] for c in fcols]] = FW
    Tn = T / np.maximum(np.linalg.norm(T, axis=1, keepdims=True), 1e-12)
    Fn = F / np.maximum(np.linalg.norm(F, axis=1, keepdims=True), 1e-12)
    S = Tn @ Fn.T
    r, c = linear_sum_assignment(-S)
    match = {int(i): int(j) for i, j in zip(r, c)}  # true index -> fitted index
    cosines = [S[i, match[i]] if i in match else 0.0 for i in range(K)]
    assign = {j: int(np.argmax(S[:, j])) for j in range(S.shape[1])}  # fitted index -> nearest true topic
    groups = {i: [j for j, t in assign.items() if t == i] for i in range(K)}
    pairs = ", ".join(f"t{i}->{fnames[match[i]] if i in match else 'none'} {cosines[i]:.3f}" for i in range(K))
    min_s = min(cosines[i] for i in structured)
    report("COSINE", min_s >= TOL["cosine"], f"min over structured topics {min_s:.3f} (>= {TOL['cosine']}), over all {min(cosines):.3f}; {pairs}")

    # document mixtures
    tdoc, tdcols, TD = read_matrix(os.path.join(a.truth, "doc_topic.csv"), "doc_id", only_topics=True)
    fdoc, fdcols, FD = read_matrix(os.path.join(a.fit, "doc_topics.csv"), "doc_id", only_topics=True)
    ttop = [tdcols.index(c) for c in topic_columns(tdcols)]
    ftop = [fdcols.index(c) for c in topic_columns(fdcols)]
    fpos = {d: i for i, d in enumerate(fdoc)}
    missing = [d for d in tdoc if d not in fpos]
    common = [d for d in tdoc if d in fpos]
    if missing:
        print(f"note: {len(missing)} truth documents absent from doc_topics.csv (for example {missing[:3]})")
    tpos_doc = {tdcols[c]: n for n, c in enumerate(ttop)}  # true topic name -> column in TDm
    fpos_doc = {fdcols[c]: n for n, c in enumerate(ftop)}  # fitted topic name -> column in FDm
    TDm = TD[[tdoc.index(d) for d in common]][:, ttop]
    FDm = FD[[fpos[d] for d in common]][:, ftop]
    tcol = [tpos_doc.get(tnames[i]) for i in range(K)]
    if any(c is None for c in tcol):
        raise SystemExit("truth doc_topic.csv lacks a column for some planted topic")
    mapped = np.zeros_like(TDm)
    for i in range(K):
        for j in groups[i]:
            c = fpos_doc.get(fnames[j])
            if c is not None:
                mapped[:, tcol[i]] += FDm[:, c]
    tcs = [tcol[i] for i in structured]
    tco = [tcol[i] for i in other]
    bad_cells = int((~np.isfinite(FD[:, ftop])).sum()) + int((~np.isfinite(TD[:, ttop])).sum())  # over every row, not only the common ones
    if common and not bad_cells:
        diff = np.abs(TDm[:, tcs] - mapped[:, tcs]).sum(axis=1) + np.abs(TDm[:, tco].sum(axis=1) - mapped[:, tco].sum(axis=1))
        tv = float(np.mean(0.5 * diff))
    else:
        tv = float("nan")
    report("TV", bool(tv <= TOL["tv"]) and not missing and bool(common) and not bad_cells,
           f"mean total variation {tv:.3f} (<= {TOL['tv']}); {len(common)} documents compared, {len(missing)} missing, {bad_cells} empty or non-numeric mixture cells")

    # quarterly shares
    tq, tqcols, TQ = read_matrix(os.path.join(a.truth, "period_share.csv"), "quarter", only_topics=True)
    fq, fqcols, FQ = read_matrix(os.path.join(a.fit, "period_share.csv"), "quarter", only_topics=True)
    tqt = [tqcols.index(c) for c in topic_columns(tqcols)]
    fqt = [fqcols.index(c) for c in topic_columns(fqcols)]
    tpos_q = {tqcols[c]: n for n, c in enumerate(tqt)}
    fpos_q = {fqcols[c]: n for n, c in enumerate(fqt)}
    fqpos = {q: i for i, q in enumerate(fq)}
    # quarters present in both tables with a value in the fitted table (an empty fitted quarter counts as missing)
    qs = [q for q in tq if q in fqpos and not np.isnan(FQ[fqpos[q]][fqt]).any()]
    TQm = TQ[[tq.index(q) for q in qs]][:, tqt]
    FQm = FQ[[fqpos[q] for q in qs]][:, fqt]
    TQs = np.column_stack([TQm[:, tpos_q[tnames[i]]] for i in range(K)]) if qs else np.zeros((0, K))
    FQa = np.zeros((len(qs), K))
    for i in range(K):
        for j in groups[i]:
            c = fpos_q.get(fnames[j])
            if c is not None:
                FQa[:, i] += FQm[:, c]
    x = np.arange(len(qs), dtype=float)
    enough = len(qs) == len(tq) and len(qs) >= 4
    trend_lines, trend_ok = [], enough
    cm = params["comoving"]
    if enough:
        for i in structured:
            if not groups[i]:
                trend_lines.append(f"t{i} unmatched")
                trend_ok = False
                continue
            rr = pearson(TQs[:, i], FQa[:, i])
            line = f"t{i} r={rr:.3f}"
            if not (rr >= TOL["trend_r"]):
                trend_ok = False
            if i in (params["rising"], params["falling"]):
                st = np.polyfit(x, TQs[:, i], 1)[0]
                sf = np.polyfit(x, FQa[:, i], 1)[0]
                ratio = sf / st if st != 0 else float("nan")
                line += f" slope ratio={ratio:.3f}"
                if not (TOL["slope_lo"] <= ratio <= TOL["slope_hi"]):
                    trend_ok = False
            trend_lines.append(line)
    else:
        trend_lines.append("too few quarters in common to compare")
    report("TREND", trend_ok, f"{len(qs)} of {len(tq)} quarters matched; " + "; ".join(trend_lines))

    worst, worst_pair = 0.0, None
    worst_s, worst_s_pair = 0.0, None
    corr_ok = enough
    rt_cm = rf_cm = float("nan")
    if enough:
        for i in range(K):
            for j in range(i + 1, K):
                rt = pearson(TQs[:, i], TQs[:, j])
                if groups[i] and groups[j]:
                    rf = pearson(FQa[:, i], FQa[:, j])
                    d = abs(rf - rt) if np.isfinite(rf) and np.isfinite(rt) else float("inf")
                else:
                    rf, d = float("nan"), float("inf")
                if d > worst:
                    worst, worst_pair = d, (i, j, rt, rf)
                if i in structured and j in structured:
                    if d > worst_s:
                        worst_s, worst_s_pair = d, (i, j, rt, rf)
                    if not d <= TOL["corr"]:
                        corr_ok = False
        rt_cm = pearson(TQs[:, cm[0]], TQs[:, cm[1]])
        rf_cm = pearson(FQa[:, cm[0]], FQa[:, cm[1]]) if groups[cm[0]] and groups[cm[1]] else float("nan")
    report("CORR", corr_ok, f"max |fitted - realized| over structured pairs {worst_s:.3f} (<= {TOL['corr']}) at pair {worst_s_pair[:2] if worst_s_pair else None}; co-moving pair realized {rt_cm:.3f}, fitted {rf_cm:.3f}; over all pairs {worst:.3f} at {worst_pair[:2] if worst_pair else None}")

    print(f"RECOVERY: {'PASS' if ok_all else 'FAIL'}")
    if a.json:
        json.dump({"planted_k": K, "chosen_k": k_fit, "match": {f"topic_{i}": fnames[match[i]] for i in match},
                   "groups": {f"topic_{i}": [fnames[j] for j in groups[i]] for i in range(K)},
                   "cosines": [float(c) for c in cosines], "tv": float(tv), "checks": results, "pass": bool(ok_all)},
                  open(a.json, "w"), indent=1)
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
